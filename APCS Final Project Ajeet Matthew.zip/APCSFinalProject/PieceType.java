/**
 * 
 *  Contains values of PieceTypes which pieces use
 *
 *  @author  Ajeet, Matthew
 *  @version May 28, 2019
 *  @author  Period: 4th
 *  @author  Assignment: APCSFinalProject
 *
 *  @author  Sources: NONE
 */
public enum PieceType {
    ONE, TWO, THREE
}
